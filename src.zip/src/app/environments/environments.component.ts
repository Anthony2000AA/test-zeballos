import { Component } from '@angular/core';

@Component({
  selector: 'app-environments',
  standalone: true,
  imports: [],
  templateUrl: './environments.component.html',
  styleUrl: './environments.component.css'
})
export class EnvironmentsComponent {

}
